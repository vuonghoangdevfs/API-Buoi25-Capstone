//prototype
export class UserAccount {
    name = '';
    email ='';
    password = '';
    gender ='';
    phone = '';
}
